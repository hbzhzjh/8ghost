<style type="text/css">
<!--
.STYLE2 {color: #000000; font-family: "΢���ź�"; font-size: 36px;}
.STYLE3 {color: #000000}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
body {
	background-image: url();
	background-color: #0099FF;
}
.STYLE6 {
	color: #FF0000;
	font-family: "΢���ź�";
}
.STYLE7 {font-family: "΢���ź�"}
.STYLE10 {font-size: 36px; font-family: "΢���ź�"; }
.STYLE12 {
	color: #FFFFFF;
	font-family: "΢���ź�";
	font-size: 18px;
}
.STYLE13 {
	color: #FFFFFF;
	font-family: "΢���ź�";
	font-size: 36px;
}
-->
</style>
<title>8Ghost�������ϵͳ��̨��¼</title>
<p>&nbsp;</p>
<table width="596" height="364" border="1" align="center" valign="center"  cellpadding="0" cellspacing="0">
  <tr>
    <td width="777" height="362" bgcolor="#66FF00"><form action="" method="post">
      <div align="center">
        <p class="STYLE2">&nbsp;</p>
        <p class="STYLE13">8Ghost�������ϵͳ��̨��¼</p>
        <p class="STYLE2">&nbsp;</p>
        <table cellspacing="0">
          <tbody>
            <!--
<tr><th>�û���</th><td><input name="username" value="">
</td></tr>
-->
            <tr>
              <th class="STYLE12">���룺</th>
              <td><span class="STYLE10">
                <input type="password" name="password" />
                <input type="submit" value="��¼" />
              </span></td>
            </tr>
          </tbody>
        </table>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p><a href="https://github.com/943551369/8ghost" class="STYLE6">���°汾/�������԰汾����</a></p>
        <p>
          <!--
<p><input type="submit" value="��¼">
</p><div></div>
-->
          <span class="STYLE7">Copyright &copy; 2016 <a href="http://xszq.tk/" class="STYLE3">943551369</a> All Rights Reserved.</span></p>
      </div>
    </form></td>
  </tr>
</table>
