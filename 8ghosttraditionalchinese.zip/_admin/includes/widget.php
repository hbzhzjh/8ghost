_type = $type;
	}
	
	function set($name,$value){
		$this->_info[$name] = $value;
		return $this;
	}
	
	//�D�Q���ַ���
	function __tostring(){
		ob_star();
		$this->e();
		$out = ob_get_contents();
		ob_end_clean();
		return $out;
	}
	
	//ݔ��
	function e(){
		$info = $this->_info;
		include(ADIR.'template/_widget/'.$this->_type.'.php');
		return $this;
	}
}