<?php include tpl('header');?>
<?php include tpl('menu');?>
	<div class="main">
		<div class="mside side" style="width:316px;padding-right:10px;">
			<form action="" method="POST">
				<h2 class="section-header">���Ӄ�����Q</h2>
				<?php
					w('text')->set('name','���Q')
							->set('key','name')
							->set('tipe','�H����ӛ��')
							->e();
			
					w('text')->set('name','���҃���')
							->set('key','seach')
							->set('tipe','������Ҫ��Q�ă���,�����tƥ��')
							->e();
					
					w('textarea')->set('name','��Q��')
							->set('key','replace')
							->set('tipe','�����ҵ��ă�����Q��')
							->e();
				?>
				<input type="submit" class="m-button" value="�ύ" id="submit">
			</form>
		</div>
		<div class="main">
			<h2 class="section-header">������Q�б�</h2>
			<table class="ae-table ae-table-striped ae-quota-requests">
	        <thead>
	            <tr>
	                <th width="35%">
	                    ���Q
	                </th>
	                <th>
	                    ����
	                </th>
	                <th>
	                    ��Q��
	                </th>
	            </tr>
	        </thead>
	        <tbody>
	        	<?php
	        		$replaces = d('config')->get('replaces');
	        		$i = 'class="ae-even"';
	        		if(is_array($replaces))
	        		foreach($replaces as $key => $item){
	        			if($i == 'class="ae-even"'){
	        				$i = '';
	        			}else{
	        				$i = 'class="ae-even"';
	        			}
	        			?>
	        	<tr <?php _e($i);?>>
	                <td>
	                	<div class="row-title">
		                    <a href="./?m=site&a=EditReplace&key=<?php _e($key)?>" title="��݋<?php _e($item['name'])?>"><?php _e($item['name'])?></a>
	                	</div>
	                    <div class="row actions">
	                        <span><a href="./?m=site&a=editReplace&key=<?php _e($key)?>">��݋</a> | </span>
	                        <span><a href="./?m=site&a=delReplace&key=<?php _e($key)?>">�h��</a></span>
	                    </div>
	                </td>
	                <td>
	                   <?php _e(htmlspecialchars($item['seach']))?>
	                </td>
	                <td>
	                    <?php _e(htmlspecialchars($item['replace']))?>
	                </td>
	            </tr>
	        			<?php
	        		}
	        	?>
	            </tbody><tfoot>
		            <tr>
		                <td width="35%">
		                    ���Q
		                </td>
		                <td>
		                    ����
		                </td>
		                <td>
		                    ��Q��
		                </td>
		            </tr>
	            </tfoot>
	        
	    </table>	
		</div>
	</div>
<?php include tpl('footer');?>