<?php include tpl('header');?>
<?php include tpl('menu');?>
<style type="text/css">
<!--
.STYLE1 {font-family: "΢ܛ�ź�"}
-->
</style>

	<div class="main">
		<h2 class="section-header STYLE1">�Զ��x���(<?php _e($page[name])?>) - <a href="./?m=page&a=edit&key=<?php _e($_GET['key'])?>">����</a>
			 - <a href="./?m=page&a=Advanced&key=<?php _e($_GET['key'])?>">�߼�</a>
			 - ������Q		</h2>
		<div class="mside side STYLE1" style="width:316px;padding-right:10px;">
			<form action="" method="POST">
				<h2 class="section-header">���Ӄ�����Q</h2>
				<?php
					w('text')->set('name','���Q')
							->set('key','name')
							->set('tipe','�H����ӛ��')
							->e();
			
					w('text')->set('name','���҃���')
							->set('key','seach')
							->set('tipe','������Ҫ��Q�ă���,�����tƥ��')
							->e();
					
					w('textarea')->set('name','��Q��')
							->set('key','replace')
							->set('tipe','�����ҵ��ă�����Q��')
							->e();
				?>
				<input type="submit" class="m-button" value="����" id="submit">
			</form>
		</div>
		<div class="main STYLE1">
			<h2 class="section-header">������Q�б�</h2>
			<table class="ae-table ae-table-striped ae-quota-requests">
	        <thead>
	            <tr>
	                <th width="35%">
	                    ���Q	                </th>
	                <th>
	                    ����	                </th>
	                <th>
	                    ��Q��	                </th>
	            </tr>
	        </thead>
	        <tbody>
	        	<?php
	        		$pages = d('config')->get('pages');
	        		$key = $_GET['key'];
					$replaces = $pages[$key]['replaces'];
	        		$i = 'class="ae-even"';
	        		if(is_array($replaces))
	        		foreach($replaces as $rekey => $item){
	        			if($i == 'class="ae-even"'){
	        				$i = '';
	        			}else{
	        				$i = 'class="ae-even"';
	        			}
	        			?>
	        	<tr <?php _e($i);?>>
	                <td>
	                	<div class="row-title">
		                    <a href="./?m=page&a=EditReplace&key=<?php _e($key)?>&rekey=<?php _e($rekey)?>" title="��݋<?php _e($item['name'])?>"><?php _e($item['name'])?></a>	                	</div>
	                    <div class="row actions">                          <a href="./?m=page&a=editReplace&key=<?php _e($key)?>&rekey=<?php _e($rekey)?>">��݋</a> |                          <a href="./?m=page&a=delReplace&key=<?php _e($key)?>&rekey=<?php _e($rekey)?>">�h��</a>	                    </div>	                </td>
	                <td>
	                   <?php _e(htmlspecialchars($item['seach']))?>	                </td>
	                <td>
	                    <?php _e(htmlspecialchars($item['replace']))?>	                </td>
	            </tr>
	        			<?php
	        		}
	        	?>
	            </tbody><tfoot>
		            <tr>
		                <td width="35%">
		                    ���Q		                </td>
		                <td>
		                    ����		                </td>
		                <td>
		                    ��Q��		                </td>
		            </tr>
	            </tfoot>
	    </table>	
		</div>
	</div>
    <span class="STYLE1">
    <?php include tpl('footer');?>
    </span>